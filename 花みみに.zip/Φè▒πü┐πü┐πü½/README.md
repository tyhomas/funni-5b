# HTML5b
An HTML5 port of Cary Huang's flash game [BFDIA 5b](http://bfdi.tv/5b/) using only pureJS and HTML5. Everything relating to the gameplay has been implemented and the level creator has had all its major functionalities implemented. Once all the minor fixes are implemented; I will move on to adding the 5b level sharing platform called "Explore".

A lot of the code in here I didn't write. Since actionscript is so similar to javascript; a lot of the code was just copy-pasted from the decompiled swf with some minor reformatting.